﻿Public Class BankAccount

    ' Private field: can only be changed from inside this class
    Private _balance As Decimal

    ' Read-only property: other code can read the balance but cannot set it
    Public ReadOnly Property Balance As Decimal
        Get
            Return _balance
        End Get
    End Property

    ' Constructor: a new account starts at 0 unless an opening balance is given
    Public Sub New(Optional openingBalance As Decimal = 0D)
        If openingBalance < 0D Then
            Throw New ArgumentException("Opening balance cannot be negative.")
        End If
        _balance = openingBalance
    End Sub

    ' Adds money to the account; rejects negative (and zero) amounts
    Public Sub Deposit(amount As Decimal)
        If amount <= 0D Then
            Throw New ArgumentException("Deposit amount must be greater than zero.")
        End If
        _balance += amount
    End Sub

    ' Removes money from the account; rejects negative (and zero) amounts and overdrafts
    Public Sub Withdraw(amount As Decimal)
        If amount <= 0D Then
            Throw New ArgumentException("Withdrawal amount must be greater than zero.")
        End If
        If amount > _balance Then
            Throw New InvalidOperationException("Insufficient funds: withdrawal would overdraw the account.")
        End If
        _balance -= amount
    End Sub

End Class