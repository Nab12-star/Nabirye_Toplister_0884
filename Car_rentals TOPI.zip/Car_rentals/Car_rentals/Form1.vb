﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cboCarType.Items.Add("Sedan")
        cboCarType.Items.Add("SUV")
        cboCarType.Items.Add("Truck")
    End Sub

    Private Sub cboCarType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboCarType.SelectedIndexChanged
        If cboCarType.SelectedItem Is Nothing Then
            Exit Sub
        End If

        Select Case cboCarType.SelectedItem.ToString()
            Case "Sedan"
                MsgBox("Daily Charge: UGX 150,000")
            Case "SUV"
                MsgBox("Daily Charge: UGX 290,000")
            Case "Truck"
                MsgBox("Daily Charge: UGX 350,000")
        End Select
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim dailyCharge As Double
        Dim daysRented As Double
        Dim totalCost As Double

        ' Get the daily charge based on selected car type
        Select Case cboCarType.SelectedItem.ToString()
            Case "Sedan"
                dailyCharge = 150000
            Case "SUV"
                dailyCharge = 290000
            Case "Truck"
                dailyCharge = 350000
            Case Else
                MsgBox("Please select a car type.")
                Exit Sub
        End Select

        ' Validate days input
        If Not IsNumeric(txtDays.Text) Then
            MsgBox("Please enter a valid number of days.")
            Exit Sub
        End If

        daysRented = CDbl(txtDays.Text)

        ' Calculate total cost
        totalCost = dailyCharge * daysRented

        ' Display in output field
        txtTotalCost.Text = totalCost.ToString("N0")
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        cboCarType.SelectedIndex = -1
        txtDays.Clear()
        txtTotalCost.Clear()
    End Sub

End Class