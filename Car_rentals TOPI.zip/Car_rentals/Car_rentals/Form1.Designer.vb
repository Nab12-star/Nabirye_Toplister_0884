﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Label1 = New Label()
        cboCarType = New ComboBox()
        Label2 = New Label()
        txtDays = New TextBox()
        btnCalculate = New Button()
        btnClear = New Button()
        Label3 = New Label()
        txtTotalCost = New TextBox()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(319, 61)
        Label1.Name = "Label1"
        Label1.Size = New Size(55, 15)
        Label1.TabIndex = 0
        Label1.Text = "Car Type:"
        ' 
        ' cboCarType
        ' 
        cboCarType.DropDownStyle = ComboBoxStyle.DropDownList
        cboCarType.FormattingEnabled = True
        cboCarType.Location = New Point(325, 125)
        cboCarType.Name = "cboCarType"
        cboCarType.Size = New Size(121, 23)
        cboCarType.TabIndex = 1
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(357, 178)
        Label2.Name = "Label2"
        Label2.Size = New Size(75, 15)
        Label2.TabIndex = 2
        Label2.Text = "Days Rented:"
        ' 
        ' txtDays
        ' 
        txtDays.Location = New Point(319, 215)
        txtDays.Name = "txtDays"
        txtDays.Size = New Size(100, 23)
        txtDays.TabIndex = 3
        ' 
        ' btnCalculate
        ' 
        btnCalculate.Location = New Point(325, 278)
        btnCalculate.Name = "btnCalculate"
        btnCalculate.Size = New Size(75, 23)
        btnCalculate.TabIndex = 4
        btnCalculate.Text = "Calculate"
        btnCalculate.UseVisualStyleBackColor = True
        ' 
        ' btnClear
        ' 
        btnClear.Location = New Point(325, 331)
        btnClear.Name = "btnClear"
        btnClear.Size = New Size(75, 23)
        btnClear.TabIndex = 5
        btnClear.Text = "Clear"
        btnClear.UseVisualStyleBackColor = True
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(350, 373)
        Label3.Name = "Label3"
        Label3.Size = New Size(62, 15)
        Label3.TabIndex = 6
        Label3.Text = "Total Cost:"
        ' 
        ' txtTotalCost
        ' 
        txtTotalCost.Location = New Point(367, 416)
        txtTotalCost.Name = "txtTotalCost"
        txtTotalCost.ReadOnly = True
        txtTotalCost.Size = New Size(100, 23)
        txtTotalCost.TabIndex = 7
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(txtTotalCost)
        Controls.Add(Label3)
        Controls.Add(btnClear)
        Controls.Add(btnCalculate)
        Controls.Add(txtDays)
        Controls.Add(Label2)
        Controls.Add(cboCarType)
        Controls.Add(Label1)
        Name = "Form1"
        Text = "Car Rental System"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents cboCarType As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtDays As TextBox
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents txtotalCost As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtTotalCost As TextBox

End Class
