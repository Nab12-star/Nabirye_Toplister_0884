
Imports System
Imports System.IO

Module Program

    Private ReadOnly filePath As String =
        Path.Combine(AppContext.BaseDirectory, "Students.txt")

    Sub Main(args As String())
        Dim choice As String

        Do
            Console.Clear()
            Console.WriteLine("========================================")
            Console.WriteLine("   STUDENT RECORDS MANAGEMENT SYSTEM")
            Console.WriteLine("========================================")
            Console.WriteLine("1. Add Student Record")
            Console.WriteLine("2. Display Student Records")
            Console.WriteLine("3. Exit")
            Console.WriteLine()
            Console.Write("Enter your choice: ")

            choice = Console.ReadLine()

            Select Case choice
                Case "1"
                    AddStudent()
                Case "2"
                    DisplayStudents()
                Case "3"
                    Console.WriteLine("Thank you for using the system.")
                Case Else
                    Console.WriteLine("Invalid choice. Please select 1, 2, or 3.")
            End Select

            If choice <> "3" Then
                Console.WriteLine()
                Console.Write("Press any key to continue...")
                Console.ReadKey()
            End If

        Loop Until choice = "3"
    End Sub

    Private Sub AddStudent()
        Console.WriteLine()
        Console.WriteLine("--- Add Student Record ---")

        Console.Write("Enter student REG NO: ")
        Dim studentID As String = Console.ReadLine()

        Console.Write("Enter student name: ")
        Dim studentName As String = Console.ReadLine()

        Console.Write("Enter student marks: ")
        Dim marks As String = Console.ReadLine()

        If String.IsNullOrWhiteSpace(studentID) OrElse
           String.IsNullOrWhiteSpace(studentName) OrElse
           String.IsNullOrWhiteSpace(marks) Then

            Console.WriteLine("All fields are required.")
            Return
        End If

        Try
            Using writer As New StreamWriter(filePath, True)
                writer.WriteLine(studentID & "|" & studentName & "|" & marks)
            End Using

            Console.WriteLine("Student record saved successfully.")

        Catch ex As IOException
            Console.WriteLine("File error: " & ex.Message)
        Catch ex As UnauthorizedAccessException
            Console.WriteLine("Access denied: " & ex.Message)
        End Try
    End Sub

    Private Sub DisplayStudents()
        Console.WriteLine()
        Console.WriteLine("--- Student Records ---")

        Try
            If Not File.Exists(filePath) Then
                Console.WriteLine("No student records found yet.")
                Return
            End If

            Dim records() As String = File.ReadAllLines(filePath)

            If records.Length = 0 Then
                Console.WriteLine("No student records found yet.")
                Return
            End If

            Console.WriteLine("{0,-28} {1,-25} {2,5}", "Student REG NO", "Student Name", "Marks")
            Console.WriteLine(New String("-"c, 70))

            For Each record As String In records
                Dim fields() As String = record.Split("|"c)

                If fields.Length = 3 Then
                    Console.WriteLine("{0,-28} {1,-25} {2,5}",
                                      fields(0), fields(1), fields(2))
                End If
            Next

        Catch ex As IOException
            Console.WriteLine("File error: " & ex.Message)
        Catch ex As UnauthorizedAccessException
            Console.WriteLine("Access denied: " & ex.Message)
        End Try
    End Sub

End Module
